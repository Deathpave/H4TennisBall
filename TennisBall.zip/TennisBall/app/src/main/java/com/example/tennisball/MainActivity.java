package com.example.tennisball;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ImageView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    SensorManager sm;
    ImageView ball;
    List list;

    float dx = 0;
    float dy = 0;
    float screenX = 0;
    float screenY = 0;

    SensorEventListener sel = new SensorEventListener(){
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values;
            dx = values[0];
            dy = values[1]- (float)9.8;
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ball = findViewById(R.id.imageBall);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        list = sm.getSensorList(Sensor.TYPE_ACCELEROMETER);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenX = displayMetrics.widthPixels;
        screenY = displayMetrics.heightPixels;

        ImageView ball = findViewById(R.id.imageBall);
        if (list.size() > 0)
        {
            sm.registerListener(sel,(Sensor)list.get(0), SensorManager.SENSOR_DELAY_NORMAL);
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    while(true)
                    {
                        float bx = ball.getX();
                        float by = ball.getY();

                    if (ball.getX() > 840)
                    {
                        dx = (dx/2)*-1;
                    }
                    else if (ball.getX() < 0)
                    {
                        dx = (dx/2)*-1;
                    }

                    if (ball.getY() > 1345)
                    {
                        dy = (dy/2)*-1;
                    }
                    else if (ball.getY() < 5 )
                    {
                        dy = (dy/2)*-1;
                    }
                    else
                    {
                        ball.setX(ball.getX()+dx);
                        ball.setY(ball.getY()+dy);
                    }
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            t.start();
        }
        else {
            onStop();
        }
    }

    @Override protected void  onStop() {
        if (list.size() > 0)
        {
            sm.unregisterListener(sel);
        }
        super.onStop();
    }
}